package javafxGUI.DataClass;

public class Menu {

}
