package javafxGUI.DataClass;

import java.util.ArrayList;

public class Employee {
    private String e_PhoneNum;
    private String e_Name;
    private int e_ID;
    private int e_Pin;
    ArrayList<Employee> employeeAccount = new ArrayList<>();

    public Employee(){
        e_ID = 1000;
        e_Pin = 1000;
        e_Name = "default";
        e_PhoneNum = "555-555-5555";
    }

    public void addEmployee(Employee employee){
       employeeAccount.add(employee);
    }

    public Employee(int e_ID, int e_Pin){
        this.e_ID = e_ID;
        this.e_Pin = e_Pin;
    }

    public String getE_PhoneNum() {
        return e_PhoneNum;
    }

    public void setE_PhoneNum(String e_PhoneNum) {
        this.e_PhoneNum = e_PhoneNum;
    }

    public String getE_Name() {
        return e_Name;
    }

    public void setE_Name(String e_Name) {
        this.e_Name = e_Name;
    }

    public int getE_ID() {
        return e_ID;
    }

    public void setE_ID(int e_ID) {
        this.e_ID = e_ID;
    }

    public int getE_Pin() {
        return e_Pin;
    }

    public void setE_Pin(int e_Pin) {
        this.e_Pin = e_Pin;
    }


}
