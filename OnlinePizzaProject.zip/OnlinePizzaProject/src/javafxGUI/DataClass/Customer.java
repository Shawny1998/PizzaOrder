package javafxGUI.DataClass;

public class Customer {
}
