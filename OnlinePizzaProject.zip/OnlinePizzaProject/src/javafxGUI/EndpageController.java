package javafxGUI;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;

import java.io.File;
import java.io.IOException;

public class EndpageController {
    @FXML
    private Button returnButton;

    public void handleReturnButton() throws IOException {
        File file = new File("sale.txt");
        if(file.exists())
            file.delete();
        try{
            file.createNewFile();
        }catch (Exception e){
            e.printStackTrace();
        }
        file = new File("calPrice.txt");
        if(file.exists())
            file.delete();
        try{
            file.createNewFile();
        }catch (Exception e){
            e.printStackTrace();
        }
        file = new File("pay.txt");
        if(file.exists())
            file.delete();
        try{
            file.createNewFile();
        }catch (Exception e){
            e.printStackTrace();
        }
        Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
        Stage window = (Stage) returnButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));
    }

}
