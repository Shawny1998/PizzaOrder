package javafxGUI;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;


public class ReceiptPageController implements Initializable {

    @FXML
    private TextArea receiptText;
    @FXML
    private Button cancelButton;
    @FXML
    private Button printButton;

    public void initialize(URL location, ResourceBundle resources){

        double estimatedTax = Double.parseDouble(readPriceRecord()) * 0.06;
        String estiTaxString = String.format("%.2f", estimatedTax);
        double total = Double.parseDouble(readPriceRecord()) + estimatedTax + 5;

        receiptText.appendText("                            Mom & Pops Pizzeria\n");
        receiptText.appendText("                              1234, Pizza Rd.\n");
        receiptText.appendText("                            Marietta, GA, 30008\n");
        receiptText.appendText("                           4/14/2022 12:20:11 PM\n");
        receiptText.appendText("                                  Pickup\n");
        receiptText.appendText("\n");
        receiptText.appendText("Order Number: 123\n");
        readRecord();
        receiptText.appendText("\n\n");
        receiptText.appendText("Sub Total:          $" + readPriceRecord() + "\n");
        receiptText.appendText("Tax:                   $" + estiTaxString + "\n");
        receiptText.appendText("Delivery Fee:       $" + 5.00 +  "\n");
        receiptText.appendText("Total:                 $" + total +  "\n");
        receiptText.appendText("\nPayment Type: ");
        readPayRecord();
        receiptText.appendText("\n\n");
        receiptText.appendText("x_________________________________________________________________\n");
        receiptText.appendText("                                    Have a nice day!");

    }


    public void readRecord(){
        File file = null;
        Scanner input = null;

        try{
            file = new File("sale.txt");
            input = new Scanner(file);

            while(input.hasNextLine()){
                String str = input.nextLine();
                receiptText.appendText(str + "\n");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }finally {
            if(input != null){
                input.close();
            }
        }
    }

    public String readPriceRecord(){
        File file = null;
        Scanner input = null;
        double price = 0.0;
        try{
            file = new File("calPrice.txt");
            input = new Scanner(file);
            while(input.hasNextLine()){
                price += Double.parseDouble(input.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }finally {
            if(input != null){
                input.close();
            }
        }
        return "" + price;
    }

    public void handlecancelButton() throws IOException {
        File file = new File("sale.txt");
        if(file.exists())
            file.delete();
        try{
            file.createNewFile();
        }catch (Exception e){
            e.printStackTrace();
        }
        file = new File("calPrice.txt");
        if(file.exists())
            file.delete();
        try{
            file.createNewFile();
        }catch (Exception e){
            e.printStackTrace();
        }
        Parent root = FXMLLoader.load(getClass().getResource("homePage.fxml"));
        Stage window = (Stage) cancelButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));
    }

    public void handlePrintButton() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Endpage.fxml"));
        Stage window = (Stage) printButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));
    }

    public void readPayRecord(){
        File file = null;
        Scanner input = null;

        try{
            file = new File("pay.txt");
            input = new Scanner(file);

            while(input.hasNextLine()){
                String str = input.nextLine();
                receiptText.appendText(str + '\n');
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }finally {
            if(input != null){
                input.close();
            }
        }
    }

}
