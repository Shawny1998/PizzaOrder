package javafxGUI;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class EditProPageController implements Initializable {

    @FXML
    private Button backButton;
    @FXML
    private Button homeButton;
    @FXML
    private Button cancelButton;
    @FXML
    private Button updateButton;
    @FXML
    private Label nameLabel;
    @FXML
    private Label eIDLabel;
    @FXML
    private Label pNumLabel;
    @FXML
    private TextField nameField;
    @FXML
    private TextField pNumberField;
    @FXML
    private TextField currentPinField;
    @FXML
    private TextField newPinField;
    @FXML
    private Label wrongLabel;

    public void initialize(URL location, ResourceBundle resources){
        nameField.setText(SigninController.employeeList.get(0).getE_Name());
        eIDLabel.setText(SigninController.employeeList.get(0).getE_ID() + "");
        pNumberField.setText(SigninController.employeeList.get(0).getE_PhoneNum());
    }

    public void handleBackButton() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("profilePage.fxml"));
        Stage window = (Stage) backButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));
    }

    public void handleHomeButton() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
        Stage window = (Stage) homeButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));
    }

    public void handlecancelButton() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("profilePage.fxml"));
        Stage window = (Stage) homeButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));
    }

    public void handleUpdateButton() throws IOException {
        if(Integer.parseInt(currentPinField.getText()) == SigninController.employeeList.get(0).getE_Pin()){
            SigninController.employeeList.get(0).setE_Name(nameField.getText());
            SigninController.employeeList.get(0).setE_PhoneNum(pNumberField.getText());
            if(!(newPinField.getText().equals("")))
            SigninController.employeeList.get(0).setE_Pin(Integer.parseInt(newPinField.getText()));
        }else{
            wrongLabel.setText("Password Incorrect");
            return;
        }
        Parent root = FXMLLoader.load(getClass().getResource("profilePage.fxml"));
        Stage window = (Stage) updateButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));

    }
}
