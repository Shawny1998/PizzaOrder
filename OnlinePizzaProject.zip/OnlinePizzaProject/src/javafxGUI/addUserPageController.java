package javafxGUI;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafxGUI.DataClass.Employee;

import java.io.IOException;
import java.util.ArrayList;

public class addUserPageController {

    @FXML
    private Button backButton;
    @FXML
    private Button homeButton;
    @FXML
    private Button submitButton;
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField phoneTextField;
    @FXML
    private TextField idTextField;
    @FXML
    private TextField pinTextField;
    @FXML
    private Label nameLabel;
    @FXML
    private Label pNumberLabel;
    @FXML
    private Label eIDLabel;
    @FXML
    private Label ePinLabel;



    public void handleBackButton() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
        Stage window = (Stage) backButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));
    }

    public void handleHomeButton() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
        Stage window = (Stage) homeButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));
    }

    public void handleSubmitButton() throws IOException {
        boolean goNext = true;
        if(nameTextField.getText().equals("")){
            nameLabel.setText("Cannot be empty");
            goNext = false;
        }else {
            nameLabel.setText("");
        }
        if(phoneTextField.getText().equals("")){
            pNumberLabel.setText("Cannot be empty");
            goNext = false;
        }else{
            pNumberLabel.setText("");
        }
        if(idTextField.getText().equals("")){
            eIDLabel.setText("Cannot be empty");
            goNext = false;
        }else{
            eIDLabel.setText("");
        }
        if(pinTextField.getText().equals("")){
            ePinLabel.setText("Cannot be empty");
            goNext = false;
        }else{
            ePinLabel.setText("");
        }
        if(goNext){
            Employee e = new Employee(Integer.parseInt(idTextField.getText()), Integer.parseInt(pinTextField.getText()));
            SigninController.employeeList.add(e);
            e.setE_Name(nameTextField.getText());
            e.setE_PhoneNum(phoneTextField.getText());
            Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
            Stage window = (Stage) homeButton.getScene().getWindow();
            window.setScene(new Scene(root,700,400));
        }
    }

}
