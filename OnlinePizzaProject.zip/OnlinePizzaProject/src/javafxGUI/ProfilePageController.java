package javafxGUI;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ProfilePageController implements Initializable {
    @FXML
    private Button backButton;
    @FXML
    private Button homeButton;
    @FXML
    private Label nameLabel;
    @FXML
    private Label eIDLabel;
    @FXML
    private Label pNumLabel;
    @FXML
    private Button EditButton;

    public void initialize(URL location, ResourceBundle resources){
        nameLabel.setText(SigninController.employeeList.get(0).getE_Name());
        eIDLabel.setText(SigninController.employeeList.get(0).getE_ID() + "");
        pNumLabel.setText(SigninController.employeeList.get(0).getE_PhoneNum());
    }

    public void handleBackButton() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
        Stage window = (Stage) backButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));
    }

    public void handleHomeButton() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
        Stage window = (Stage) homeButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));
    }

    public void handleEditButton() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("editProPage.fxml"));
        Stage window = (Stage) EditButton.getScene().getWindow();
        window.setScene(new Scene(root,700,400));
    }
}
