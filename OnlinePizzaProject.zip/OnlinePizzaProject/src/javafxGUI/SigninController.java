package javafxGUI;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafxGUI.DataClass.Employee;

public class SigninController implements Initializable {

    @FXML
    Button submitButton;
    @FXML
    TextField eIDField;
    @FXML
    TextField ePinField;
    @FXML
    Label wrongIDLabel;

    static ArrayList<Employee> employeeList = new ArrayList<Employee>();

    public void initialize(URL location, ResourceBundle resources){
        Employee e = new Employee();
        employeeList.add(e);
    }

    public void handlesubmitButton() throws IOException {

        try{
            for(Employee e: employeeList){
                if (Integer.parseInt(eIDField.getText()) == e.getE_ID()) {
                    if(Integer.parseInt(ePinField.getText()) == e.getE_Pin()){
                        Employee temp = employeeList.get(0);
                        employeeList.set(0,e);
                        e = temp;
                        Parent root = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
                        Stage window = (Stage) submitButton.getScene().getWindow();
                        window.setScene(new Scene(root, 700, 400));
                    }
                    else {
                        wrongIDLabel.setText("ID or Password not correct, try it again");
                    }
                } else {
                    wrongIDLabel.setText("ID or Password not correct, try it again");
                }
            }
        }catch (Exception e){
            wrongIDLabel.setText("Employee ID and Password should be number only");
        }


        }


}
